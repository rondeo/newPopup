var proxySource = {
    "servers": [
        {
            "url": "91.208.39.70",
            "port": 8080,
            "type": "PROXY"
        },
        {
            "url": "138.201.223.250",
            "port": 31288,
            "type": "PROXY"
        },
        {
            "url": "149.56.102.220",
            "port": 3128,
            "type": "PROXY"
        },
        {
            "url": "163.172.218.228",
            "port": 8181,
            "type": "PROXY"
        },
        {
            "url": "80.240.25.63",
            "port": 1080,
            "type": "PROXY"
        },
        {
            "url": "92.53.64.234",
            "port": 3128,
            "type": "PROXY"
        },
        {
            "url": "185.81.154.46",
            "port": 3128,
            "type": "PROXY"
        }
    ]
};



