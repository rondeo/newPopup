(function(){
var settings;

// settings
var initSettings = function () {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get('settings', function (data) {
            if (data.settings) settings = data.settings;
            resolve(settings);
        });
    });
};

// add toolbar
var skipPositionedChild = function (node, style) {
    if (this.offsetParent &&
        this.offsetParent.tagName !== 'BODY') return true;
    if (hasPositionedParent(node)) return true;
    return false;
};

var hasPositionedParent = function (node) {
    if (node.tagName === 'BODY') return false;
    var parent = node.parentNode;
    var position = getComputedStyle(parent).position;
    if (position !== 'static') {
        return true;
    }
    return hasPositionedParent(parent);
};


var addtoolbar = function () {
    var checka = document.querySelector('#mchex-toolbar');
    if (checka) {
        console.log('#mchex-toolbar already exist')
    } else {
        var height = '50px';

        var Children = document.body.getElementsByTagName("*");

        for (var i = 0, len = Children.length; i < len; i++) {

            if (Children[i].currentStyle) {
                var x = Children[i].currentStyle["position"];
                var y = Children[i].currentStyle["top"];
                var z = Children[i].currentStyle["bottom"];
                var q = Children[i].currentStyle["height"];
            } else if (window.getComputedStyle) {
                var st = document.defaultView.getComputedStyle(Children[i], null);
                var x = st.getPropertyValue("position");
                var y = st.getPropertyValue("top");
                var z = st.getPropertyValue("bottom");
                var q = st.getPropertyValue("height");
            }

            if ((x == "absolute" || x == "fixed") && y !== 'auto') {
                if (x === 'absolute' && skipPositionedChild(Children[i])) {
                } else {
                    Children[i].setAttribute("data-financetoolbar", true);
                    Children[i].setAttribute("data-sfttop", Children[i].style.top);
                    Children[i].style.top = parseInt(y, 10) + parseInt(height, 10) + "px";
                    // if "top" and "bottom" is 0 => then calc height
                    if (q != "auto" && (y == "0px" && z == "0px")) {
                        Children[i].setAttribute("data-sftheight", q);
                        Children[i].style.height = "calc(100% - " + height + ")";
                    }

                }
            }
        }

        var toolbar = document.createElement("div");
        toolbar.setAttribute('id', 'mchex-toolbar');
        toolbar.classList.add("mchex-toolbar-mini");

        var frame = document.createElement("iframe");
        frame.setAttribute("src", "" + chrome.runtime.getURL('/html/toolbar-mini.html') + "");
        toolbar.appendChild(frame);
        document.body.insertBefore(toolbar, document.body.firstChild);

        var html = document.getElementsByTagName("HTML")[0];
        html.style.marginTop = height;
    }
};

// remove toolbar

var removetoolbar = function () {
    var html = document.getElementsByTagName("HTML")[0];
    html.style.marginTop = 0;
    var checkb = document.querySelector('#mchex-toolbar');
    if (checkb) {
        document.body.removeChild(checkb);

        var a = document.querySelectorAll('[data-financetoolbar]');

        var a = document.body.getElementsByTagName("*");
        for (var i = 0, len = a.length; i < len; i++) {
            if (a[i].hasAttribute("data-sfttop")) {
                a[i].style.top = a[i].getAttribute("data-sfttop");
            }
            if (a[i].hasAttribute("data-sftbottom")) {
                a[i].style.bottom = a[i].getAttribute("data-sftbottom");
            }
            if (a[i].hasAttribute("data-sftheight")) {
                a[i].style.height = a[i].getAttribute("data-sftheight");
            }
            a[i].setAttribute("data-financetoolbar", false);
        }

    }
}



// add video

var openVideoOnMainpage = function () {
    var tabsGraph = document.createElement("div");
    tabsGraph.id = "mmCrExt-PlayVideoContainer";
    tabsGraph.classList.add("zoomInDown");
    tabsGraph.style.width = "520px";
    tabsGraph.style.height = "293px";
    tabsGraph.style.background = "#ffffff";
    tabsGraph.style.top = "60px";
    tabsGraph.style.left = "32%";
    tabsGraph.style.border = "2px solid darkgrey";
    tabsGraph.style.position = "fixed";
    tabsGraph.style.zIndex = "999999";

    var ifr = document.createElement("iframe");
    ifr.style.src = "self";
    ifr.src = "https://www.youtube.com/embed/videoseries?autoplay=1&list=PL01B35E3369F92B65";
    ifr.width = "520";
    ifr.height = "293";
    ifr.allowfullscreen = "";
    ifr.frameBorder = "0";
    ifr.style.height = "100%";
    tabsGraph.prepend(ifr);
    document.getElementsByTagName("body")[0].prepend(tabsGraph);

}

// remove video

var closeAllDivOnMainPage = function () {
    var video = document.getElementById("mmCrExt-PlayVideoContainer");
    if (video) {
        video.classList.add("zoomOutUp");
        setTimeout(function () {
            video.parentNode.removeChild(video);
        }, 1000);
    }
    ;
}



// toggle Toolbar

var toggleToolbar = function (cond) {

    cond ? addtoolbar() : removetoolbar()
}


// toggle video

var toggleVideo = function (cond) {

    cond ? openVideoOnMainpage() : closeAllDivOnMainPage()
}


// document onLoad

document.addEventListener("DOMContentLoaded", function () {
    chrome.runtime.sendMessage({
        cmd: 'tab.ready-mmCrExt'
    }, function (response) {
       // console.log(response);
    });
});


// on Message
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.cmd === 'toggleWidget-mmCrExt') {
            toggleToolbar(request.data);
        } else if (request.cmd === 'toggleVideo-mmCrExt') {
            toggleVideo(request.data);
        }
    });


// window.onscroll = function () {
    // var scrollTop = document.scrollingElement.scrollTop;
    // var html = document.getElementsByTagName("HTML")[0];
    // if (scrollTop < 50) {
    //     var mt = scrollTop - 50;
    //     html.style.marginTop = mt + "px";
    //     html.style.paddingTop = 50 + "px";
    //
    // }

// };
})();

