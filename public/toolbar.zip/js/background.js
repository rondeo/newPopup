(function () {

    // settings

    var settings = {
        enableToolbar: true,
    };

    var initSettings = function () {
        getSettings()
            .then(function (respone) {
                if (respone) {
                    settings = respone;
                }
            })
            .catch(function (error) {
                console.log(error)
            })
            .finally(function () {
                setSettings(settings);
            })
    };


    var getSettings = function () {
        return new Promise(function (resolve, reject) {
            chrome.storage.local.get('mmCrExtSettings', function (data) {
                data.mmCrExtSettings ? resolve(data.mmCrExtSettings) : resolve(null);
            });
        });
    };

    var setSettings = function (settings) {
        chrome.storage.local.set({'mmCrExtSettings': settings});
    };

    // messaging

    var initMessaging = function () {
        chrome.runtime.onMessage.addListener(
            function (request, sender, sendResponse) {
                var cmd = request.cmd;
                var data = request.data;
                var tabId = (sender.tab || {}).id;
                switch (cmd) {
                    case 'tab.ready-mmCrExt':
                        chrome.tabs.sendMessage(tabId,
                            {
                                cmd: 'toggleWidget-mmCrExt',
                                data: settings.enableToolbar
                            });
                        break;
                    case "toggleWidget-mmCrExt":
                        toolbarToggle();
                        break;
                    default:
                        return
                }
            });
    };

    //icon

    var setIcon = function (isOn, tabId) {
        var path = chrome.extension.getURL('img/icon128_gray.png');
        if (isOn) path = chrome.extension.getURL('img/icon128.png');
        chrome.browserAction.setIcon({
            tabId: tabId,
            path: path
        });
    };


    // toolbar Toggle

    var toolbarToggle = function (tab) {
        settings.enableToolbar = !settings.enableToolbar;
        setSettings(settings);
        setIcon(settings.enableToolbar);
        chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id,
                {
                    cmd: 'toggleWidget-mmCrExt',
                    data: settings.enableToolbar
                });
        });
    };

    // init

    var init = function () {
        initSettings();
        initMessaging();
    };

    init();
})();
